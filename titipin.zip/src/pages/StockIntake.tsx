import { useCallback, useEffect, useMemo, useState, type KeyboardEvent } from 'react'
import { Check, Grid2X2, List, PackagePlus, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useToast } from '../components/Toast'
import { useConfirm } from '../components/ConfirmDialog'
import PageHeader from '../components/PageHeader'
import EmptyState from '../components/EmptyState'
import NewProductModal from '../components/NewProductModal'
import DatePicker from '../components/DatePicker'
import ViewOptions, { type OptionGroup } from '../components/ViewOptions'
import SupplierPicker from '../components/SupplierPicker'
import { useStoredState } from '../lib/prefs'
import { todayWIB } from '../lib/dates'
import CartDock from '../components/CartDock'
import { errText } from '../lib/errors'
import { imageUrl } from '../lib/image'
import { rupiah } from '../lib/format'
import './BarangMasuk.css'

const EXP_PRESETS = [
  { label: 'Besok', days: 1 },
  { label: '+3 hari', days: 3 },
  { label: '+1 minggu', days: 7 },
  { label: '+2 minggu', days: 14 },
]

const LAST_SUPPLIER_KEY = 'titipin:barangmasuk:supplier'

/** Pilihan tampilan katalog. Kuncinya sama dengan Kasir, jadi memakai gaya yang sama. */
const VIEW_DEFAULTS = {
  entry: 'cepat', // cepat = tabel isi langsung, katalog = pilih kartu lalu isi di panel
  view: 'grid',
  size: 'm',
  density: 'comfy',
  sort: 'usual',
  showImage: true,
  cart: 'right',
  cartWidth: 'normal',
}
const VIEW_GROUPS: OptionGroup[] = [
  { type: 'seg', key: 'entry', label: 'Cara mengisi', hint: 'Cepat: ketik stok langsung di tabel, Enter pindah ke baris berikutnya.', choices: [{ value: 'cepat', label: 'Cepat (tabel)' }, { value: 'katalog', label: 'Katalog (kartu)' }] },
  { type: 'seg', key: 'view', label: 'Bentuk daftar produk', choices: [{ value: 'grid', label: 'Kartu', icon: Grid2X2 }, { value: 'list', label: 'Daftar', icon: List }, { value: 'compact', label: 'Ringkas' }] },
  { type: 'seg', key: 'size', label: 'Ukuran kartu', choices: [{ value: 's', label: 'Kecil' }, { value: 'm', label: 'Sedang' }, { value: 'l', label: 'Besar' }] },
  { type: 'seg', key: 'density', label: 'Kerapatan', choices: [{ value: 'comfy', label: 'Lega' }, { value: 'tight', label: 'Padat' }] },
  { type: 'seg', key: 'sort', label: 'Urutkan produk', choices: [{ value: 'usual', label: 'Biasa dititip dulu' }, { value: 'name', label: 'A–Z' }] },
  { type: 'toggle', key: 'showImage', label: 'Tampilkan gambar' },
  { type: 'seg', key: 'cart', label: 'Posisi daftar (layar lebar)', choices: [{ value: 'right', label: 'Kanan' }, { value: 'left', label: 'Kiri' }] },
  { type: 'seg', key: 'cartWidth', label: 'Lebar daftar (layar lebar)', choices: [{ value: 'narrow', label: 'Sempit' }, { value: 'normal', label: 'Normal' }, { value: 'wide', label: 'Lebar' }] },
]

interface Product {
  id: number
  name: string
  category_id: number | null
  image_path: string | null
  supplier_id: number | null
  unit: string | null
}
interface Hist {
  cost: number
  sell: number
}
interface Entry {
  productId: number
  qty: string
  cost: string
  sell: string
  expired: string
}

export default function StockIntake() {
  const notify = useToast()
  const confirm = useConfirm()
  const [suppliers, setSuppliers] = useState<{ id: number; name: string }[]>([])
  const [categories, setCategories] = useState<{ id: number; name: string }[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [supplierId, setSupplierId] = useState('')
  const [history, setHistory] = useState<Map<number, Hist>>(new Map())
  // isian disimpan per supplier, jadi berpindah supplier tidak menghapus apa pun
  const [drafts, setDrafts] = useState<Record<string, Entry[]>>({})
  const [search, setSearch] = useState('')
  const [cat, setCat] = useState('') // '' = semua, 'biasa' = biasa dititip, selain itu = id kategori
  const [sheet, setSheet] = useState(false)
  const [newOpen, setNewOpen] = useState(false)
  const [editProduct, setEditProduct] = useState<Product | null>(null)
  const [busy, setBusy] = useState(false)
  const [recent, setRecent] = useState<Map<number, { rank: number; products: number }>>(new Map())
  const [prefs, setPrefs, resetPrefs] = useStoredState('titipin:barangmasuk:tampilan:v1', VIEW_DEFAULTS)

  const loadLists = useCallback(async () => {
    const [s, c, p, r] = await Promise.all([
      supabase.from('suppliers').select('id, name').eq('is_active', true).order('name'),
      supabase.from('categories').select('id, name').order('name'),
      supabase.from('products').select('id, name, category_id, image_path, supplier_id, unit').eq('is_active', true).order('name'),
      supabase.from('stock_batches').select('supplier_id, product_id').order('id', { ascending: false }).limit(600),
    ])
    // supplier yang paling baru menitip tampil paling depan
    const rec = new Map<number, { rank: number; products: Set<number> }>()
    for (const row of (r.data ?? []) as { supplier_id: number; product_id: number }[]) {
      const cur = rec.get(row.supplier_id) ?? { rank: rec.size, products: new Set<number>() }
      cur.products.add(row.product_id)
      rec.set(row.supplier_id, cur)
    }
    setRecent(new Map([...rec].map(([id, v]) => [id, { rank: v.rank, products: v.products.size }])))
    if (s.error) notify(errText(s.error), 'error')
    setSuppliers((s.data ?? []) as { id: number; name: string }[])
    setCategories((c.data ?? []) as { id: number; name: string }[])
    setProducts((p.data ?? []) as Product[])
    setLoading(false)
  }, [notify])

  // harga terakhir yang dipakai untuk setiap produk dari supplier ini
  const loadHistory = useCallback(
    async (sid: string) => {
      if (!sid) {
        setHistory(new Map())
        return undefined
      }
      const { data, error } = await supabase
        .from('stock_batches')
        .select('product_id, cost_price, sell_price')
        .eq('supplier_id', Number(sid))
        .order('id', { ascending: false })
        .limit(1000)
      if (error) {
        notify(errText(error), 'error')
        return undefined
      }
      const m = new Map<number, Hist>()
      for (const r of (data ?? []) as { product_id: number; cost_price: number; sell_price: number }[]) {
        if (!m.has(r.product_id)) m.set(r.product_id, { cost: r.cost_price, sell: r.sell_price })
      }
      setHistory(m)
      return m
    },
    [notify],
  )

  useEffect(() => {
    void loadLists()
  }, [loadLists])

  useEffect(() => {
    void (async () => {
      const m = await loadHistory(supplierId)
      setCat(m && m.size > 0 ? 'biasa' : '')
    })()
  }, [supplierId, loadHistory])

  /** Daftar supplier untuk dipilih: yang paling baru menitip di depan. */
  const rail = useMemo(
    () => [...suppliers].sort((a, b) => (recent.get(a.id)?.rank ?? 1e6) - (recent.get(b.id)?.rank ?? 1e6) || a.name.localeCompare(b.name)),
    [suppliers, recent],
  )

  // langsung buka supplier terakhir yang dipakai (atau yang paling baru menitip), tanpa harus memilih dulu
  useEffect(() => {
    if (loading || supplierId || rail.length === 0) return
    let saved = ''
    try {
      saved = localStorage.getItem(LAST_SUPPLIER_KEY) ?? ''
    } catch {
      /* abaikan */
    }
    setSupplierId(rail.some((x) => String(x.id) === saved) ? saved : String(rail[0].id))
  }, [loading, supplierId, rail])

  useEffect(() => {
    if (!supplierId) return
    try {
      localStorage.setItem(LAST_SUPPLIER_KEY, supplierId)
    } catch {
      /* abaikan */
    }
  }, [supplierId])

  const entries = drafts[supplierId] ?? []
  const setEntries = (next: Entry[] | ((es: Entry[]) => Entry[])) =>
    setDrafts((d) => ({ ...d, [supplierId]: typeof next === 'function' ? next(d[supplierId] ?? []) : next }))
  const quick = prefs.entry === 'cepat'
  // mode cepat: baris tanpa stok dianggap belum diisi dan tidak ikut disimpan
  const activeOf = (list: Entry[]) => (quick ? list.filter((e) => e.qty.trim() !== '') : list)

  const productById = useMemo(() => new Map(products.map((p) => [p.id, p])), [products])
  const catName = useMemo(() => new Map(categories.map((c) => [c.id, c.name])), [categories])
  const supplierName = suppliers.find((s) => String(s.id) === supplierId)?.name ?? ''
  // setiap barang milik satu supplier: hanya tampilkan barang supplier yang sedang dipilih
  const supplierProducts = useMemo(() => products.filter((p) => String(p.supplier_id) === supplierId), [products, supplierId])
  const usualCount = supplierProducts.filter((p) => history.has(p.id)).length
  const selectedIds = new Set(entries.map((e) => e.productId))

  const q = search.trim().toLowerCase()
  const visible = supplierProducts
    .filter((p) => {
      if (q && !p.name.toLowerCase().includes(q)) return false
      if (cat === 'biasa') return history.has(p.id)
      if (cat !== '') return String(p.category_id) === cat
      return true
    })
    .sort((a, b) => (prefs.sort === 'usual' ? Number(history.has(b.id)) - Number(history.has(a.id)) : 0) || a.name.localeCompare(b.name))

  const totals = entries.reduce(
    (t, e) => {
      const n = Number(e.qty) || 0
      return { qty: t.qty + n, cost: t.cost + n * (Number(e.cost) || 0), sell: t.sell + n * (Number(e.sell) || 0) }
    },
    { qty: 0, cost: 0, sell: 0 },
  )

  const blank = (id: number): Entry => {
    const h = history.get(id)
    return { productId: id, qty: '', cost: h ? String(h.cost) : '', sell: h ? String(h.sell) : '', expired: '' }
  }

  function toggle(p: Product) {
    setEntries((es) => (es.some((e) => e.productId === p.id) ? es.filter((e) => e.productId !== p.id) : [...es, blank(p.id)]))
  }

  function addUsual() {
    setEntries((es) => {
      const have = new Set(es.map((e) => e.productId))
      return [...es, ...supplierProducts.filter((p) => history.has(p.id) && !have.has(p.id)).map((p) => blank(p.id))]
    })
    setSheet(true)
  }

  function patch(productId: number, field: 'qty' | 'cost' | 'sell' | 'expired', value: string) {
    setEntries((es) => es.map((e) => (e.productId === productId ? { ...e, [field]: value } : e)))
  }

  function changeSupplier(v: string) {
    if (v === supplierId) return
    setSheet(false)
    setSearch('')
    setSupplierId(v)
  }

  async function clearEntries() {
    const ok = await confirm({ title: 'Kosongkan daftar?', message: 'Semua produk yang dipilih akan dihapus dari daftar.', confirmText: 'Ya, kosongkan', tone: 'danger' })
    if (ok) {
      setEntries([])
      setSheet(false)
    }
  }

  const supplierLabel = (sid: string) => suppliers.find((x) => String(x.id) === sid)?.name ?? 'Supplier'

  function validateList(list: Entry[]): string {
    if (list.length === 0) return 'Pilih minimal satu produk.'
    for (const e of list) {
      const nm = productById.get(e.productId)?.name ?? 'Produk'
      const qty = Number(e.qty)
      const cost = Number(e.cost)
      const sell = Number(e.sell)
      if (e.qty.trim() === '' || !Number.isInteger(qty) || qty <= 0) return `${nm}: stok wajib diisi dan harus lebih dari 0.`
      if (e.cost.trim() === '' || !Number.isInteger(cost) || cost < 0) return `${nm}: harga supplier wajib diisi (angka bulat, minimal 0).`
      if (e.sell.trim() === '' || !Number.isInteger(sell) || sell < 0) return `${nm}: harga jual wajib diisi (angka bulat, minimal 0).`
      if (e.expired === '') return `${nm}: tanggal expired wajib diisi.`
      if (e.expired < todayWIB()) return `${nm}: tanggal expired sudah lewat.`
    }
    return ''
  }

  /** Simpan isian satu supplier, atau semua supplier yang sudah ada isiannya. */
  async function saveAll(only?: string) {
    const sids = only ? [only] : Object.keys(drafts).filter((k) => activeOf(drafts[k] ?? []).length > 0)
    if (sids.length === 0) {
      notify('Belum ada barang yang diisi.', 'error')
      return
    }
    for (const sid of sids) {
      const msg = validateList(activeOf(drafts[sid] ?? []))
      if (msg) {
        notify(sids.length > 1 ? `${supplierLabel(sid)}: ${msg}` : msg, 'error')
        if (sid !== supplierId) changeSupplier(sid)
        return
      }
    }
    const bad = sids.flatMap((sid) =>
      activeOf(drafts[sid] ?? [])
        .filter((e) => Number(e.sell) < Number(e.cost))
        .map((e) => productById.get(e.productId)?.name ?? 'Produk'),
    )
    if (bad.length > 0) {
      const ok = await confirm({
        title: 'Harga jual di bawah harga supplier',
        message: `${bad.join(', ')}. Barang ini akan dijual rugi. Tetap simpan?`,
        confirmText: 'Ya, tetap simpan',
        tone: 'danger',
      })
      if (!ok) return
    }

    setBusy(true)
    const done: string[] = []
    let count = 0
    for (const sid of sids) {
      const list = activeOf(drafts[sid] ?? [])
      const items = list.flatMap((e) => {
        const pr = productById.get(e.productId)
        return pr
          ? [{ name: pr.name, category: catName.get(pr.category_id ?? -1) ?? '', unit: pr.unit ?? 'pcs', qty: Number(e.qty), cost_price: Number(e.cost), sell_price: Number(e.sell), expired_date: e.expired, image_path: null }]
          : []
      })
      const { error } = await supabase.rpc('add_stock_batches', { p_supplier_id: Number(sid), p_items: items })
      if (error) {
        notify(`${supplierLabel(sid)}: ${errText(error)}`, 'error')
        break
      }
      done.push(sid)
      count += items.length
    }
    setBusy(false)
    if (done.length === 0) return
    setDrafts((d) => {
      const next = { ...d }
      for (const sid of done) delete next[sid]
      return next
    })
    setSheet(false)
    notify(
      done.length === 1
        ? `${count} produk dari ${supplierLabel(done[0])} dicatat. Harganya diingat untuk input berikutnya.`
        : `${count} produk dari ${done.length} supplier dicatat.`,
    )
    await loadHistory(supplierId)
    await loadLists()
  }

  /** Isi satu kolom untuk satu produk langsung dari tabel (mode cepat). */
  function setCell(p: Product, field: 'qty' | 'cost' | 'sell' | 'expired', value: string) {
    setEntries((es) => {
      const i = es.findIndex((e) => e.productId === p.id)
      if (i === -1) {
        if (value === '') return es
        return [...es, { ...blank(p.id), [field]: value }]
      }
      const next = es.map((e, j) => (j === i ? { ...e, [field]: value } : e))
      const e = next[i]
      const h = history.get(p.id)
      const untouched = (h ? e.cost === String(h.cost) && e.sell === String(h.sell) : e.cost === '' && e.sell === '') && e.expired === ''
      return field === 'qty' && value === '' && untouched ? next.filter((_, j) => j !== i) : next
    })
  }

  /** Enter pada kolom stok langsung pindah ke baris berikutnya. */
  function nextQty(ev: KeyboardEvent<HTMLInputElement>) {
    if (ev.key !== 'Enter') return
    ev.preventDefault()
    const all = Array.from(document.querySelectorAll<HTMLInputElement>('input[data-qty]'))
    all[all.indexOf(ev.currentTarget) + 1]?.focus()
  }

  // ringkasan semua supplier yang sudah ada isiannya
  const draftSids = Object.keys(drafts).filter((k) => activeOf(drafts[k] ?? []).length > 0)
  const all = draftSids.reduce(
    (t, sid) => {
      for (const e of activeOf(drafts[sid] ?? [])) t = { products: t.products + 1, qty: t.qty + (Number(e.qty) || 0) }
      return t
    },
    { products: 0, qty: 0 },
  )

  const dockBody = entries.map((e) => {
    const p = productById.get(e.productId)
    if (!p) return null
    const h = history.get(e.productId)
    const cost = Number(e.cost)
    const sell = Number(e.sell)
    const hasPrices = e.cost !== '' && e.sell !== ''
    const margin = sell - cost
    const changed = !!h && hasPrices && (cost !== h.cost || sell !== h.sell)
    return (
      <div className="entry" key={e.productId}>
        <div className="entry-top">
          {p.image_path ? <img className="cl-img" src={imageUrl(p.image_path)} alt="" /> : <div className="cl-img" />}
          <div style={{ minWidth: 0, flex: 1 }}>
            <div className="cl-name">{p.name}</div>
            <div className="page-sub">{h ? `Terakhir: ${rupiah(h.cost)} / ${rupiah(h.sell)}` : 'Belum pernah dititip supplier ini'}</div>
          </div>
          <button type="button" className="icon-btn" style={{ minHeight: 34, minWidth: 34 }} onClick={() => setEditProduct(p)} aria-label={`Ubah produk ${p.name}`}>
            <Pencil size={15} />
          </button>
          <button className="icon-btn" style={{ minHeight: 34, minWidth: 34 }} onClick={() => toggle(p)} aria-label={`Hapus ${p.name} dari daftar`}>
            <Trash2 size={16} />
          </button>
        </div>
        <div className="entry-fields">
          <label>
            Stok
            <input type="number" min={1} inputMode="numeric" value={e.qty} onChange={(ev) => patch(e.productId, 'qty', ev.target.value)} />
          </label>
          <label>
            Harga supplier
            <input type="number" min={0} inputMode="numeric" value={e.cost} onChange={(ev) => patch(e.productId, 'cost', ev.target.value)} />
          </label>
          <label>
            Harga jual
            <input type="number" min={0} inputMode="numeric" value={e.sell} onChange={(ev) => patch(e.productId, 'sell', ev.target.value)} />
          </label>
          <label>
            Expired
            <DatePicker min={todayWIB()} value={e.expired} onChange={(v) => patch(e.productId, 'expired', v)} ariaLabel="Expired" placeholder="Pilih tanggal" presets={EXP_PRESETS} />
          </label>
        </div>
        {hasPrices && (
          <span className={`hint${margin < 0 ? ' warn' : ''}`}>
            {margin < 0 ? `Rugi ${rupiah(-margin)} per pcs` : `Untung ${rupiah(margin)} per pcs${sell > 0 ? ` (${Math.round((margin / sell) * 100)}%)` : ''}`}
          </span>
        )}
        {changed && h && <span className="hint warn">Berbeda dari harga terakhir ({rupiah(h.cost)} / {rupiah(h.sell)})</span>}
      </div>
    )
  })

  const controls = (
    <>
            <div className="toolbar pos-toolbar" style={{ marginBottom: 0 }}>
              <div className="search" style={{ maxWidth: 'none' }}>
                <Search size={18} />
                <input placeholder="Cari produk…" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <button className="btn-icon" disabled={!supplierId} onClick={() => setNewOpen(true)}>
                <Plus size={16} /> <span className="bm-new-label">Barang baru</span>
              </button>
              <ViewOptions groups={VIEW_GROUPS} values={prefs} onChange={(k, v) => setPrefs({ [k]: v } as Partial<typeof prefs>)} onReset={resetPrefs} />
            </div>

            <div className="pills-scroll pills-wrap">
              {usualCount > 0 && (
                <button type="button" className={`pill${cat === 'biasa' ? ' on' : ''}`} onClick={() => setCat('biasa')}>
                  Biasa dititip ({usualCount})
                </button>
              )}
              <button type="button" className={`pill${cat === '' ? ' on' : ''}`} onClick={() => setCat('')}>Semua</button>
              {categories.map((c) => (
                <button key={c.id} type="button" className={`pill${cat === String(c.id) ? ' on' : ''}`} onClick={() => setCat(String(c.id))}>
                  {c.name}
                </button>
              ))}
            </div>

            {!quick && cat === 'biasa' && usualCount > 0 && (
              <div className="notice notice-info" style={{ alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap' }}>
                <span>Produk yang biasa dititip {supplierName}. Harga terakhir terisi otomatis.</span>
                <button type="button" className="btn-sm" onClick={addUsual}>Pilih semua ({usualCount})</button>
              </div>
            )}
    </>
  )

  const quickView = (
    <div className="bm-quickwrap">
      {controls}
      {visible.length === 0 ? (
        <EmptyState
          title="Tidak ada produk"
          text={cat === 'biasa' ? 'Belum ada riwayat titipan dari supplier ini. Pilih "Semua" untuk mengisi dari seluruh produk.' : 'Coba ubah pencarian atau kategori.'}
        />
      ) : (
        <div className="bm-quick" role="table" aria-label={`Barang masuk dari ${supplierName}`}>
          <div className="bm-qhead" aria-hidden="true">
            <span />
            <span>Produk</span>
            <span>Stok</span>
            <span>Harga supplier</span>
            <span>Harga jual</span>
            <span>Expired</span>
            <span>Laba / pcs</span>
          </div>
          {visible.map((p) => {
            const e = entries.find((x) => x.productId === p.id)
            const h = history.get(p.id)
            const cost = e?.cost ?? (h ? String(h.cost) : '')
            const sell = e?.sell ?? (h ? String(h.sell) : '')
            const filled = !!e && e.qty.trim() !== ''
            const margin = cost !== '' && sell !== '' ? Number(sell) - Number(cost) : null
            return (
              <div className={`bm-qrow${filled ? ' on' : ''}`} key={p.id} role="row">
                {p.image_path ? <img className="bm-thumb" src={imageUrl(p.image_path)} alt="" loading="lazy" /> : <span className="bm-thumb" />}
                <div className="bm-qname">
                  <strong>
                    {p.name}
                    <button type="button" className="bm-edit" onClick={() => setEditProduct(p)} aria-label={`Ubah produk ${p.name}`}>
                      <Pencil size={13} />
                    </button>
                  </strong>
                  <small>{h ? `Terakhir ${rupiah(h.cost)} / ${rupiah(h.sell)}` : 'Belum pernah dititip supplier ini'}</small>
                </div>
                <label className="bm-f bm-f-qty">
                  <span>Stok</span>
                  <input
                    data-qty
                    type="number"
                    min={1}
                    inputMode="numeric"
                    placeholder="0"
                    value={e?.qty ?? ''}
                    onFocus={(ev) => ev.currentTarget.select()}
                    onKeyDown={nextQty}
                    onChange={(ev) => setCell(p, 'qty', ev.target.value)}
                    aria-label={`Stok ${p.name}`}
                  />
                </label>
                <label className="bm-f">
                  <span>Harga supplier</span>
                  <input type="number" min={0} inputMode="numeric" value={cost} onFocus={(ev) => ev.currentTarget.select()} onChange={(ev) => setCell(p, 'cost', ev.target.value)} aria-label={`Harga supplier ${p.name}`} />
                </label>
                <label className="bm-f">
                  <span>Harga jual</span>
                  <input type="number" min={0} inputMode="numeric" value={sell} onFocus={(ev) => ev.currentTarget.select()} onChange={(ev) => setCell(p, 'sell', ev.target.value)} aria-label={`Harga jual ${p.name}`} />
                </label>
                <label className="bm-f bm-f-exp">
                  <span>Expired</span>
                  <DatePicker min={todayWIB()} value={e?.expired ?? ''} onChange={(v) => setCell(p, 'expired', v)} ariaLabel={`Expired ${p.name}`} placeholder="Pilih tanggal" presets={EXP_PRESETS} />
                </label>
                <span className={`bm-margin${margin !== null && margin < 0 ? ' loss' : ''}`}>
                  {margin === null ? '' : margin < 0 ? `Rugi ${rupiah(-margin)}` : `+${rupiah(margin)}`}
                </span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )

  const dockFoot = (
    <>
      <div>
        <div className="sum-row"><span>Total barang</span><b>{totals.qty}</b></div>
        <div className="sum-row"><span>Nilai supplier</span><b>{rupiah(totals.cost)}</b></div>
        <div className="sum-row"><span>Potensi omzet</span><b>{rupiah(totals.sell)}</b></div>
        <div className="sum-row total">
          <span>Potensi laba</span>
          <span style={{ color: totals.sell - totals.cost < 0 ? 'var(--danger)' : 'var(--success)' }}>{rupiah(totals.sell - totals.cost)}</span>
        </div>
      </div>
      <button className="btn-primary pay-btn" onClick={() => void saveAll(supplierId)} disabled={busy || entries.length === 0}>
        {busy ? 'Menyimpan…' : 'Simpan barang masuk'}
      </button>
    </>
  )

  return (
    <div>
      <PageHeader title="Barang Masuk" subtitle="Pilih supplier, pilih produk yang dititip, lalu isi stok dan harga." />

      {!loading && rail.length > 0 && (
        <SupplierPicker
          items={rail.map((sp) => ({
            id: String(sp.id),
            name: sp.name,
            sub: recent.get(sp.id)?.products ? `${recent.get(sp.id)?.products} produk biasa` : 'Belum pernah menitip',
            count: activeOf(drafts[String(sp.id)] ?? []).length,
          }))}
          value={supplierId}
          onChange={changeSupplier}
          desktop={
        <div className="bm-rail" role="group" aria-label="Pilih supplier">
          {rail.map((sp) => {
            const on = String(sp.id) === supplierId
            const n = recent.get(sp.id)?.products
            return (
              <button key={sp.id} type="button" className={`bm-sup${on ? ' on' : ''}`} aria-pressed={on} onClick={() => changeSupplier(String(sp.id))}>
                <span className="bm-avatar">{sp.name.trim().charAt(0).toUpperCase()}</span>
                <span className="bm-sup-main">
                  <strong>{sp.name}</strong>
                  <small>{n ? `${n} produk biasa` : 'Belum pernah menitip'}</small>
                </span>
                {activeOf(drafts[String(sp.id)] ?? []).length > 0 && <span className="bm-count">{activeOf(drafts[String(sp.id)] ?? []).length}</span>}
              </button>
            )
          })}
        </div>
          }
        />
      )}

      {loading ? (
        <div className="skeleton" style={{ height: 260, borderRadius: 14 }} />
      ) : suppliers.length === 0 ? (
        <EmptyState title="Belum ada supplier aktif" text="Tambahkan supplier di menu Supplier (atau aktifkan yang ada), lalu kembali ke sini untuk mencatat barang masuk." />
      ) : !supplierId ? (
        <div className="skeleton" style={{ height: 260, borderRadius: 14 }} />
      ) : supplierProducts.length === 0 ? (
        <EmptyState
          title="Belum ada barang dari supplier ini"
          text="Tambahkan barang pertama untuk supplier ini (nama, kategori, satuan, dan foto), lalu isi stok dan harganya."
          action={<button className="btn-primary" onClick={() => setNewOpen(true)}>Barang baru</button>}
        />
      ) : quick ? (
        quickView
      ) : (
        <div className="pos" data-cart={prefs.cart} data-cartw={prefs.cartWidth} data-density={prefs.density}>
          <div className="pos-main">
            {controls}

            {visible.length === 0 ? (
              <EmptyState
                title="Tidak ada produk"
                text={cat === 'biasa' ? 'Belum ada riwayat titipan dari supplier ini.' : 'Coba ubah pencarian atau kategori. Produk yang belum ada bisa dibuat lewat tombol Produk baru.'}
              />
            ) : (
              <div className="pos-grid" data-view={prefs.view} data-size={prefs.size} data-img={prefs.showImage ? 'on' : 'off'}>
                {visible.map((p) => {
                  const sel = selectedIds.has(p.id)
                  const h = history.get(p.id)
                  return (
                    <div className="tile-wrap" key={p.id}>
                    <button
                      type="button"
                      className={`tile${sel ? ' in-cart' : ''}`}
                      onClick={() => toggle(p)}
                      aria-pressed={sel}
                      aria-label={`${sel ? 'Batalkan' : 'Pilih'} ${p.name}`}
                    >
                      {p.image_path ? <img className="tile-img" src={imageUrl(p.image_path)} alt="" loading="lazy" /> : <span className="tile-img" />}
                      {h && <span className="tile-price">{rupiah(h.sell)}</span>}
                      {sel && <span className="tile-qty"><Check size={16} /></span>}
                      <span className="tile-body">
                        <span className="tile-name">{p.name}</span>
                        <span className="tile-sup">{catName.get(p.category_id ?? -1) ?? '-'}</span>
                        {h && <span className="badge badge-info">Biasa dititip</span>}
                      </span>
                    </button>
                    <button type="button" className="tile-edit" onClick={() => setEditProduct(p)} aria-label={`Ubah produk ${p.name}`}>
                      <Pencil size={14} />
                    </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          <CartDock
            title="Barang masuk"
            subtitle={`${entries.length} produk · ${totals.qty} barang`}
            hasItems={entries.length > 0}
            emptyText="Ketuk produk di katalog untuk menambahkannya ke daftar ini."
            open={sheet}
            onOpenChange={setSheet}
            onClear={() => void clearEntries()}
            bar={
              <>
                <span><PackagePlus size={18} /> {entries.length} produk</span>
                <strong>{totals.qty} barang</strong>
                <span>Isi stok &amp; harga</span>
              </>
            }
            body={dockBody}
            foot={dockFoot}
          />
        </div>
      )}

      {quick && draftSids.length > 0 && (
        <div className="bm-bar" role="region" aria-label="Ringkasan barang masuk">
          <div className="bm-bar-info">
            <b>{all.qty} barang</b>
            <span>
              dari {all.products} produk · {draftSids.length === 1 ? supplierLabel(draftSids[0]) : `${draftSids.length} supplier`}
            </span>
          </div>
          <button type="button" className="btn-primary" onClick={() => void saveAll()} disabled={busy}>
            {busy ? 'Menyimpan…' : draftSids.length > 1 ? `Simpan semua (${draftSids.length} supplier)` : 'Simpan barang masuk'}
          </button>
        </div>
      )}

      {editProduct && (
        <NewProductModal
          product={editProduct}
          supplierId={Number(supplierId) || editProduct.supplier_id || 0}
          categories={categories}
          onClose={() => setEditProduct(null)}
          onSaved={async () => {
            setEditProduct(null)
            await loadLists()
          }}
        />
      )}

      {newOpen && supplierId && (
        <NewProductModal
          supplierId={Number(supplierId)}
          supplierName={supplierName}
          categories={categories}
          onClose={() => setNewOpen(false)}
          onCreated={async (id) => {
            setNewOpen(false)
            await loadLists()
            setEntries((es) => (es.some((e) => e.productId === id) ? es : [...es, blank(id)]))
            setCat('')
            setSheet(true)
          }}
        />
      )}
    </div>
  )
}